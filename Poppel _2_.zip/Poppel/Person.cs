﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Poppel
{
    public class Person
    {
        

        #region data members
        private string id, name, phone, email, faxno, address;
        #endregion

        #region Properties  //property methods
        public string ID
        {
            get { return id; }
            set { id = value; }
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        public string Phone
        {
            get { return phone; }
            set { phone = value; }
        }
        public string Email
        {
            get { return email; }
            set { email = value; }
        }
        public string Faxno
        {
            get { return faxno; }
            set { faxno = value; }
            
        }
        public string Address
        {
            get { return address; }
            set { address = value; }
        }
        #endregion

        #region Construtor //constuctor methods
        public Person() //parameterless constructor
        {
            id = "";
            name = "";
            phone = "";
            email = "";
            faxno = "";
            address = "";
        }

        public Person(string pID, string pName, string pPhone, string pEmail, string pFaxno, string pAddress)  //parametized constructor
        {
            id = pID;
            name = pName;
            phone = pPhone;
            email = pEmail;
            faxno = pFaxno;
            address = pAddress;
            
        }
        #endregion

        #region ToStringMethod               
        public override string ToString() //an overridable ToString method to allow this class to display the details of a person.
        {
            return name + '\n' + Phone;
        }

        #endregion
    }
}
