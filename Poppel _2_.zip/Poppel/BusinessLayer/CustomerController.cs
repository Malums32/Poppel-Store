﻿using Poppel.DatabaseLayer;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Poppel.BusinessLayer
{
    public class CustomerController
    {
        #region Data Members
        private CustomerDB customerDB;//make reference 
        private Collection<Customers> customers;
        #endregion

        #region Properties
        public Collection<Customers> AllCustomers
        {
            get
            {
                return customers;
            }
        }
        #endregion

        #region Constructor
        public CustomerController()
        {
            //***instantiate the CustomerDB object to communicate with the database
            customerDB = new CustomerDB();
            customers = customerDB.AllCustomers;
        }
        #endregion

        #region Database Communication.
        public void DataMaintenance(Customers anCus, DB.DBOperation operation)
        {
            int index = 0;
            //perform a given database operation to the dataset in meory; 
            customerDB.DataSetChange(anCus, operation);//calling method to do the insert
            switch (operation)
            {
                case DB.DBOperation.Add:
                    //*** Add the customer to the Collection
                    customers.Add(anCus);
                    break;
                case DB.DBOperation.Edit:
                    index = FindIndex(anCus);
                    customers[index] = anCus;  // replace customer at this index with the updated customer
                    break;

               
            }
        }
        //***Commit the changes to the database
        public bool FinalizeChanges(Customers customers)
        {
            //***call the EmployeeDB method that will commit the changes to the database
            return customerDB.UpdateDataSource(customers);

        }
        #endregion

        #region Search Methods
        //This method  (function) searched through all the customers that are new

        public Collection<Customers> FindNewCustomer(Collection<Customers> cust)
        {
            Collection<Customers> matches = new Collection<Customers>();
            foreach (Customers customers in cust)
            {
                
                    matches.Add(customers);
                
            }
            return matches;
        }
        public Customers Find(string ID)
        {
            int index = 0;
            bool found = (customers[index].ID == ID);  //check if it is the first record
            int count = customers.Count;
            while (!(found) && (index < customers.Count - 1))  //if not "this" record and you are not at the end of the list 
            {
                index = index + 1;
                found = (customers[index].ID == ID);   // this will be TRUE if found
            }
            return customers[index];  // this is the one!  
        }

        public int FindIndex(Customers anCus)
        {
            int counter = 0;
            bool found = false;
            found = (anCus.ID == customers[counter].ID);   //using a Boolean Expression to initialise found
            while (!(found) & counter < customers.Count - 1)
            {
                counter += 1;
                found = (anCus.ID == customers[counter].ID);
            }
            if (found)
            {
                return counter;
            }
            else
            {
                return -1;
            }
        }
        #endregion
    }
}
