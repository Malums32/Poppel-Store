﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Poppel.BusinessLayer
{
    public class Customers : Person
    {
        #region Data Members
        //encapsulation
        
        private int credit;
            private int creditLimit;
        private string paymentMethod;
        
        #endregion

        #region Constructors

        public Customers()  //parameterless constructor
        {
           credit = 0;
            creditLimit = 0;
            paymentMethod = "";
        }
        public Customers(int credit, int creditLimit, string paymentMethod) //parametized constructor
        {
           this.credit = credit;
           this.creditLimit = creditLimit;
           this.paymentMethod = paymentMethod;
        }
        #endregion

        #region Property methods
        public int Credit
        {
            get { return credit; }
            set { credit = value; }
        }
       public int CreditLimit
        {
            get { return creditLimit; }
            set { creditLimit = value; }
        }
        public string PaymentMethod
        {
            get { return paymentMethod; }
            set { paymentMethod = value; }
        }

        public string lblFaxNo { get; internal set; }
        public string txtFaxNo1 { get; internal set; }
        #endregion

    }
}
