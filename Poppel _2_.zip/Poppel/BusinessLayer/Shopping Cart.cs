﻿
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Poppel.BusinessLayer
{
    public class Shopping_Cart
    {
        private List<Product> _products = new List<Product>();

        public decimal TotalPrice { get; private set; }
        public IReadOnlyCollection<Product> Products => _products;
       

        public void AddProduct(Product product)
        {
            _products.Add(product);
            TotalPrice += product.ProductPrice.Length;
        }

        public void RemoveProduct(Product product)
        {
            _products.Remove(product);
            TotalPrice += product.ProductPrice.Length;
        }
        private void RecalculateTotalPrice()
        {
            var totalPrice = 0m;
            foreach (var product in _products)
            {
                totalPrice += product.ProductPrice.Length;
            }
            TotalPrice = totalPrice;
        }
    }
}
