﻿using Poppel.DatabaseLayer;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Poppel.BusinessLayer
{
    public class ProductController
    {

        #region Data Members
        private ProductDB ProductDB;//make reference 
        private Collection<Product> product;
        #endregion

        #region Properties
        public Collection<Product> AllProducts
        {
            get
            {
                return product;
            }
        }
        #endregion

        #region Constructor
        public ProductController()
        {
            //***instantiate the ProductDB object to communicate with the database
            ProductDB = new ProductDB();
            product = ProductDB.AllProducts;
        }
        #endregion

        #region Database Communication.
        public void DataMaintenance(Product aPro, DB.DBOperation operation)
        {
            int index = 0;
            //perform a given database operation to the dataset in meory; 
            ProductDB.DataSetChange(aPro, operation);//calling method to do the insert
            switch (operation)
            {
                case DB.DBOperation.Add:
                    //*** Add the customer to the Collection
                    product.Add(aPro);
                    break;
                case DB.DBOperation.Edit:
                    index = FindIndex(aPro);
                    product[index] = aPro;  // replace customer at this index with the updated customer
                    break;

                //case DB.DBOperation.Delete:
                //    index = FindIndex(aPro);
                //    product.RemoveAt(index);  // Delete customer at this index with the updated customer
                //    break;
            }
        }
        //***Commit the changes to the database
        public bool FinalizeChanges(Product Product)
        {
            //***call the EmployeeDB method that will commit the changes to the database
            return ProductDB.UpdateDataSource(Product);

        }
        #endregion

        #region Search Methods
        //This method  (function) searched through all the Product to finds onlly those with the required role
        public Collection<Product> FindByRole(Collection<Product> Product)
        {
            Collection<Product> matches = new Collection<Product>();


            return matches;
        }
        public Product Find(string productCode)
        {
            int index = 0;
            bool found = (product[index].ProductCode == productCode);  //check if it is the first record
            int count = product.Count;
            while (!(found) && (index < product.Count - 1))  //if not "this" record and you are not at the end of the list 
            {
                index = index + 1;
                found = (product[index].ProductCode == productCode);   // this will be TRUE if found
            }
            return product[index];  // this is the one!  
        }

        public int FindIndex(Product aPro)
        {
            int counter = 0;
            bool found = false;
            found = (aPro.ProductCode == product[counter].ProductCode);   //using a Boolean Expression to initialise found
            while (!(found) & counter < product.Count - 1)
            {
                counter += 1;
                found = (aPro.ProductCode == product[counter].ProductCode);
            }
            if (found)
            {
                return counter;
            }
            else
            {
                return -1;
            }
        }
        #endregion
    }
}

