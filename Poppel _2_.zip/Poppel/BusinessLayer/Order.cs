﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Poppel.BusinessLayer
{
    public class Order
    {
        #region Data Members
        protected string orderID;
        private string orderName;   
        private string orderType;
        private string orderDate;
        private string orderPrice;
        private string orderQty;
        private string description;
     
        #endregion

        #region Property methods
        public string OrderID
        {
            get { return orderID; }
            set { orderID = value; }
        }
        public string OrderName
        {
            get { return orderName; }
            set { orderName = value; }
        }
        public string OrderType
        {
            get { return orderType; }
            set { orderType = value; }
        }
        public string OrderDate
        {
            get { return orderDate; }
            set {orderDate = value; }
        }
        public string OrderPrice
        {
            get { return orderPrice; }
            set { orderPrice = value; }
        }
        public string OrderQty
        {
            get { return orderQty; }
            set { orderQty = value; }
        }
        public string Description
        {
            get { return description; }
            set { description = value; }
        }
        public enum OrderAvail
        {
            Available,
            Expired,
        }
        
        #endregion

        #region Constructor
        public Order()
        {
            orderID = "";
            orderName = "";
            orderType = "";
            orderDate = "";
            orderPrice = "";
            orderQty = "";
            description = "";
        }
        public Order(string orderID, string orderName, string orderType, string orderDate, string orderPrice, string orderQty, string description)
        {
            OrderID = orderID;
            OrderName = orderName;
            OrderType = orderType;
            OrderDate = orderDate;
            OrderPrice = orderPrice;
            OrderQty = orderQty;
            OrderID = orderID;
            OrderName = orderName;
            OrderType = orderType;
            OrderDate = orderDate;
            OrderPrice = orderPrice;
            OrderQty = orderQty;
            Description = description;
        }

        #endregion

        #region Methods

        #endregion
    }
}
