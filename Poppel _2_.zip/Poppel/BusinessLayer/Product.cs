﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Poppel.BusinessLayer
{
    public class Product
    {
        #region Data members
        private string productCode;
        private string productName;
        private string productSize;
        private string productQuantity;
        private string productPrice;
        private string description;
        private DateTime expiryDate;
        #endregion

        #region Constructors
        public Product()
        {
            productCode = "";
            productName = "";
            productSize = "";
            productQuantity = "";
            productPrice = "";
            description = "";
        }
        public Product(string Pcode, string Pname, string Psize, string Pquantity, string Pprice, string description, DateTime expiryDate)
        {
            this.productCode = Pcode;
            this.productName = Pname;
            this.productSize = Psize;
            this.productQuantity = Pquantity;
            this.productPrice = Pprice;
            this.description = description;
            this.expiryDate = expiryDate;
            
        }
        #endregion

        #region Property methods
        public string ProductCode
        {
            get { return productCode; }
            set { productCode = value; }
        }
        public string ProductName
        {
            get { return ProductName; }
            set { productName = value; }
        }
        public string ProductSize
        {
            get { return productSize; }
            set { productSize = value; }
        }
        public string ProductQuantity
        {
            get { return productQuantity; }
            set { productQuantity = value; }
        }
        public string ProductPrice
        {
            get { return productPrice; }
            set { productPrice = value; }
        }
        public string Description
        {
            get { return description; }
            set { description = value; }
        }
        public DateTime Date
        {
            get { return expiryDate; }
            set { expiryDate = value; }
        }
        #endregion

    }
}
