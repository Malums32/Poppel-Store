﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Windows.Forms;
using Poppel.BusinessLayer;
using Poppel.DatabaseLayer;
using static Poppel.PresentationLayer.CustomerListingForm;
using System.Collections.ObjectModel;
using Poppel.Properties;

namespace Poppel.PresentationLayer
{
    public partial class ProductListingForm : Form
    {
      
        #region Variables
        public bool listFormClosed;
        private Collection<Product> products;
        private ProductController productController;
        private FormStates state;
        private Product product;
        SqlConnection con;
        SqlDataAdapter adapter;
        SqlCommand sqlCommand;
        #endregion

        #region Enumeration
        public enum FormStates
        {
            View = 0,
            Add = 1,
            Edit = 2,
      
        }
        #endregion
        public ProductListingForm()
        {
            InitializeComponent();
            con = new SqlConnection(Settings.Default.PoppelDBConnectionString);
        }
        
        ProductForm productForm = new ProductForm();

        #region Constructor
        public ProductListingForm(ProductController proController)
        {
            InitializeComponent();
            this.Load += new System.EventHandler(this.ProductListingForm_Load);
            productController = proController;
            this.Load += ProductListingForm_Load;
            this.Activated += ProductListingForm_Activated;
            state = FormStates.View;
        }

        #endregion

        private void displayGrid()
        {
            using (SqlConnection con2 = new SqlConnection(con.ConnectionString))
            {
                adapter = new SqlDataAdapter("select * from Product", con2);
                DataTable dta = new DataTable();
                adapter.Fill(dta);
                productGrid.DataSource = dta;
            }
        }
        #region The List View
        public void setUpProductListView()
        {
            ListViewItem productDetails;  //declare variables
           
            
          //  //clear current List View Control
          // listView1.Clear();
          //  //set up column of listview
          //  listView1.Columns.Insert(0, "productCode", 120, HorizontalAlignment.Left);
          //  listView1.Columns.Insert(1, "productName", 120, HorizontalAlignment.Left);
          //  listView1.Columns.Insert(2, "productSize", 120, HorizontalAlignment.Left);
          //  listView1.Columns.Insert(3, "productQuantity", 120, HorizontalAlignment.Left);
          //  listView1.Columns.Insert(4, "productPrice", 120, HorizontalAlignment.Left);
          //  listView1.Columns.Insert(5, "description", 120, HorizontalAlignment.Left);
          //  listView1.Columns.Insert(6, "ExpiryDate", 120, HorizontalAlignment.Left);
          //// products = null;

            //add product details to each Listview item
           
                  /*  foreach (Product product in products)
                    {
                        productDetails = new ListViewItem();
                        productDetails.Text = product.ProductCode.ToString();
                        productDetails.SubItems.Add(product.ProductName);
                        productDetails.Text = product.ProductSize.ToString();
                        productDetails.Text = product.ProductQuantity.ToString();
                        productDetails.Text = product.ProductPrice.ToString();
                        productDetails.SubItems.Add(product.Description);
                        productDetails.Text = product.Date.ToString();
                    //    listView1.Items.Add(productDetails);
                    }
                    //listView1.Refresh();
                    //listView1.GridLines = true;
                */
            
        }
        private void EnableEntries(bool value)
        {
            if((state == FormStates.Edit) && value)
            {
                txtId.Enabled = !value;

            }
            else
            {
                txtId.Enabled = value;
            }
            txtName.Enabled = value;
            txtSize.Enabled = value;
            txtQuantity.Enabled = value;
            txtPrice.Enabled = value;
            txtDescription.Enabled = value;
            txtExpiryDate.Enabled = value;
            
        }

        private void ClearAll()
        {
            txtId.Text = "";
            txtName.Text = "";
            txtSize.Text = "";
            txtQuantity.Text = "";
            txtPrice.Text = "";
            txtDescription.Text = "";
        }
        private void PopulateTextBoxes(Product pro)
        {
            txtId.Text = pro.ProductCode;
            txtName.Text = pro.ProductName;
            txtSize.Text = pro.ProductSize.ToString();
            txtQuantity.Text = pro.ProductQuantity.ToString();
            txtPrice.Text = pro.ProductPrice.ToString();
            txtDescription.Text = pro.Description;
            txtExpiryDate.Text = pro.Date.ToString();
        }
        private void PopulateObject()
        {
            product = new Product();
            product.ProductCode = txtId.Text;
            product.ProductName = txtName.Text;
            product.ProductSize = txtSize.Text;
            product.ProductQuantity = txtQuantity.Text;
            product.ProductPrice = txtPrice.Text;
            product.Description = txtDescription.Text;
          // product.Date = DateTime.Today(txtExpiryDate.Text);
        }
        #endregion 

        #region Form Events
        private void ProductListingForm_Activated(object sender, EventArgs e)
        {
           //listView1.View = View.Details;
            setUpProductListView();
            
        }

       
        private void ProductListingForm_Load(object sender, EventArgs e)
        {
            //listView1.View = View.Details;
            this.displayGrid();
        }
        #endregion

        #region utility methods

        #endregion

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            state = FormStates.View;
            EnableEntries(false);

            //if(listView1.SelectedItems.Count > 0)
            //{
            //    product = productController.Find(listView1.SelectedItems[0].Text);
            //    PopulateTextBoxes(product);
            //}
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            state = FormStates.Edit;
            //btnDelete.Visible = false;
            EnableEntries(true);
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            PopulateObject();
            if(state == FormStates.Edit)
            {
                productController.DataMaintenance(product, DB.DBOperation.Edit);
            }
            else
            {

            }
            productController.FinalizeChanges(product);
            ClearAll();
            setUpProductListView();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            MDIParent1 mdi = new MDIParent1();
            mdi.Show();
            this.Close();
        }

        private void ProductListingForm_Activated_1(object sender, EventArgs e)
        {
            //listView1.View = View.Details;
            setUpProductListView();

        }

        private void btnPopulate_Click(object sender, EventArgs e)
        {
            if(txtId.Text == "")
            {
                MessageBox.Show("The ProductCode is empty \n Please insert productCode first", "Error",MessageBoxButtons.OK);
            }
            else
            {
                con.Open();
                sqlCommand = new SqlCommand("select productCode, productName, productSize, productQuantity, productPrice, description, ExpiryDate from Product where productCode='" + txtId.Text + "'", con);
                SqlDataReader reader = sqlCommand.ExecuteReader();
                while (reader.Read())
                {
                    txtName.Text = reader.GetValue(1).ToString();
                    txtDescription.Text = reader.GetValue(5).ToString();
                    txtExpiryDate.Text = reader.GetValue(6).ToString();
                    txtQuantity.Text = reader.GetValue(3).ToString();
                    txtPrice.Text = reader.GetValue(4).ToString();
                    txtSize.Text = reader.GetValue(2).ToString();
                }
                con.Close();

            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtId.Text = "";
            txtName.Text = "";
            txtPrice.Text = "";
            txtQuantity.Text = "";
            txtDescription.Text = "";
            txtSize.Text = "";
            txtExpiryDate.Text = "";
        }

        private void productGrid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
