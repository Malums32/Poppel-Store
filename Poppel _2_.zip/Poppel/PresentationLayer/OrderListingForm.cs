﻿using Poppel.BusinessLayer;
using Poppel.DatabaseLayer;
using Poppel.PresentationLayer;
using Poppel.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.DirectoryServices.ActiveDirectory;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Runtime.Remoting;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using TextBox = System.Windows.Forms.TextBox;

namespace Poppel
{
    public partial class OrderListingForm : Form
    {
      

        SqlConnection connection = new SqlConnection(Settings.Default.PoppelDBConnectionString);
        private OrderDB orderDB;
        private DB dB;
        private Product pro;  
        private ProductController productController;
        Product pID;

        public OrderListingForm()
        {
            InitializeComponent();
            ProductController productController = new ProductController();
 
        }  

        public OrderListingForm(ListBox.ObjectCollection items)
        {
        }

        private void homeToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void btnCheckout_Click(object sender, EventArgs e)
        {
            OrderForm catalogue = new OrderForm(listBox1.Items);
            catalogue.Show();
        }

        private void catalogueToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OrderForm catalogue = new OrderForm();
            catalogue.Show();
        }

        private void Order_Load(object sender, EventArgs e)
        {
            txtID.Text = pro?.ProductCode ?? "Null Value";
        }
        private void PopulateTextboxesp(Product pro)
        {
            txtID.Text = pro.ProductCode;
            txtName.Text = pro.ProductName;
            txtSize.Text = pro.ProductSize.ToString();
            txtQuantity.Text = pro.ProductQuantity.ToString();
            txtPrice.Text = pro.ProductPrice.ToString();
            txtDescription.Text = pro.Description;
        }
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string val = listBox1.GetItemText(listBox1.SelectedItem);

            //if (listBox1.SelectedItems.Count > 0)
            //{
            // //product = productController.Find(listBox1.SelectedItems[0].ToString());

            //}
            //PopulateTextboxesp(pro);

            ////connection.Open();
            //if (listBox1.SelectedValue != null)
            //{
            //    using (var cn = new SqlConnection(Settings.Default.PoppelDBConnectionString))
            //    using (var cmd = new SqlCommand("Select * From [dbo].[Product]", cn))
            //    {
            //        cn.Open();
            //        cmd.CommandType = CommandType.Text;
            //        // cmd.CommandText = new CommandText(null);

            //        txtID.Text = cmd.ExecuteScalar().ToString();
            //        txtName.Text = cmd.ExecuteScalar().ToString();
            //        txtSize.Text = cmd.ExecuteScalar().ToString();
            //        txtQuantity.Text = cmd.ExecuteScalar().ToString();
            //        txtPrice.Text = cmd.ExecuteScalar().ToString();
            //        txtDescription.Text = cmd.ExecuteScalar().ToString();

            //    }

            //}

            OrderForm orderform = new OrderForm(listBox1.Text);
            this.Hide();
            orderform.Show();
        }

        private void PopulateTextboxes(Product product)
        {
            throw new NotImplementedException();
        }

        private void drinksToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ProductForm pdf = new ProductForm();
            this.Hide();
            pdf.Show();
        }

        private void checkoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Checkout checkout = new Checkout();
            this.Hide();
            checkout.Show();
        }

        private void btnShow_Click(object sender, EventArgs e)
        {

            //var dt = new DataTable();

            //using (var cn = new SqlConnection(Settings.Default.PoppelDBConnectionString))
            //using (var cmd = new SqlCommand("Select * From Product", cn))
            //{
            //    cn.Open();

            //    using (var reader = cmd.ExecuteReader())
            //    {
            //        dt.Load(reader);
            //        var results = (from row in dt.AsEnumerable()
            //                       select new
            //                       {
            //                           //UserID = row.Field<int>("ID"),
            //                           txtID = row.Field<string>("productCode"),
            //                           txtName = row.Field<string>("productName"),
            //                           txtSize = row.Field<string>("productSize"),
            //                           txtQuantity = row.Field<string>("productQuantity"),
            //                           txtPrice = row.Field<string>("productPrice"),
            //                           txtDescription = row.Field<string>("description")
            //                       }).ToList();

            //        listBox1.DataSource = results;
            //        listBox1.DisplayMember = "description";
            //    }
            //}
        }

        
    }
}



