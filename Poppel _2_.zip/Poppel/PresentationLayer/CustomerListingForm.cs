﻿using Poppel.BusinessLayer;
using System;
using System.Collections.ObjectModel;
using System.Windows.Forms;
using Poppel.DatabaseLayer;
using System.Data;
using System.Collections.Generic;
using System.Data.SqlClient;
using Poppel.Properties;
using System.Drawing;

namespace Poppel.PresentationLayer
{
    public partial class CustomerListingForm : Form
    {

        #region Variables
        public bool listFormClosed;
        private Collection<Customers> customers;
        private Customers customer;
        private CustomerController customerController;
        private FormStates state;
        SqlConnection con;
        SqlDataAdapter adapter;
        SqlCommand sqlCommand;
        #endregion

        #region Enumeration
        public enum FormStates
        {
            View = 0,
            Add = 1,
            Edit = 2,

        }
        #endregion
        #region Constructor
        public CustomerListingForm()
        {
            InitializeComponent();
            con = new SqlConnection(Settings.Default.PoppelDBConnectionString);
        }

        public CustomerListingForm(CustomerController aContoller)
        {
            InitializeComponent();
            customerController = aContoller;
            this.Load += CustomerListingForm_Load;
            this.Load += CustomerListingForm_Activated_1;
            this.Load += CustomerListingForm_FormClosed;
            state = FormStates.View;
        }
        #endregion

        private void displayGrid()
        {
            using (SqlConnection con2 = new SqlConnection(con.ConnectionString))
            {
                adapter = new SqlDataAdapter("select * from CustomerDetails", con2);
                DataTable dta = new DataTable();
                adapter.Fill(dta);
                customerGrid.DataSource = dta;
            }
        }
        #region The List View
        public void setUpCustomerListView()
        {
            ListViewItem customerDetails;   //Declare variables

            //    //Clear current List View Control
            //    CustomerslistViews.Clear();
            //    //Set Up Columns of List View
            //    CustomerslistViews.Columns.Insert(0, "ID", 120, HorizontalAlignment.Left);
            //    CustomerslistViews.Columns.Insert(1, "Name", 120, HorizontalAlignment.Left);
            //    CustomerslistViews.Columns.Insert(2, "Phone", 150, HorizontalAlignment.Left);
            //    CustomerslistViews.Columns.Insert(3, "Email", 100, HorizontalAlignment.Left);
            //    CustomerslistViews.Columns.Insert(4, "FaxNo", 100, HorizontalAlignment.Left);
            //    CustomerslistViews.Columns.Insert(5, "Address", 100, HorizontalAlignment.Left);
            //    CustomerslistViews.Columns.Insert(6, "PaymentMethod", 100, HorizontalAlignment.Left);
            //    customers = null;
            //    //customer collection will be filled 

            //    //Add customer details to each ListView item 
            //    foreach (Customers customer in customers)
            //    {
            //        customerDetails = new ListViewItem();
            //        customerDetails.Text = customer.ID.ToString();
            //        customerDetails.SubItems.Add(customer.Name);
            //        customerDetails.SubItems.Add(customer.Phone);
            //        customerDetails.SubItems.Add(customer.Email);
            //        customerDetails.SubItems.Add(customer.Faxno);
            //        customerDetails.SubItems.Add(customer.Address);
            //        customerDetails.SubItems.Add(customer.PaymentMethod);   
            //        CustomerslistViews.Items.Add(customerDetails);
            //    }
            //    CustomerslistViews.Refresh();
            //    CustomerslistViews.GridLines = true;
        }

        #endregion



        #region Form Events
        private void CustomerListingForm_FormClosed(object sender, EventArgs e)
        {
            listFormClosed = true;
        }
        private void CustomerListingForm_Load(object sender, EventArgs e)
        {
            this.displayGrid();
        }


        #endregion

        #region Utility Methods
        private void ShowAll(bool value)
        {
            //listboxes
            lblId.Visible = value;
            lblName.Visible = value;
            lblPhone.Visible = value;
            lblEmail.Visible = value;
            lblFaxNo.Visible = value;
            lblAddress.Visible = value;
            lblPaymentMethod.Visible = value;
            //comboboxws
            comboBox1.Visible = value;
            //textboxes
            txtId.Visible = value;
            txtName.Visible = value;
            txtPhone.Visible = value;
            txtEmail.Visible = value;
            txtFaxNo.Visible = value;
            txtAddress.Visible = value;
            //If the form state is View, the Update button and the Cancel button should not be visible

            if (state == FormStates.View)
            {

                btnEdit.Visible = value;
            }
        }
        private void EnableEntries(bool value)
        {
            if ((state == FormStates.Edit) && value)
            {
                txtId.Enabled = !value;
                txtName.Enabled = !value;
            }
            else
            {

                txtName.Enabled = value;
                txtPhone.Enabled = value;
                txtEmail.Enabled = value;
                txtFaxNo.Enabled = value;
                txtAddress.Enabled = value;
                comboBox1.Enabled = value;
            }

        }
        private void ClearAll()
        {
            txtId.Text = "";
            txtName.Text = "";
            txtPhone.Text = "";
            txtEmail.Text = "";
            txtFaxNo.Text = "";
            txtAddress.Text = "";
            comboBox1.Text = "";

        }
        private void PopulateObject()
        {
            customer = new Customers();
            customer.ID = txtId.Text;
            customer.Name = txtName.Text;
            customer.Phone = txtPhone.Text;
            customer.Email = txtEmail.Text;
            customer.Faxno = txtFaxNo.Text;
            customer.Address = txtAddress.Text;
            customer.PaymentMethod = comboBox1.Text;
        }
        private void PopulateTextBoxes(Customers anCus)
        {

            txtId.Text = anCus.ID;
            txtName.Text = anCus.Name;
            txtPhone.Text = anCus.Phone;
            txtEmail.Text = anCus.Email;
            txtFaxNo.Text = anCus.Faxno;
            txtAddress.Text = anCus.Address;
            comboBox1.Text = anCus.PaymentMethod;
        }
        #endregion   

        private void lblList_Click(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        

        private void button1_Click(object sender, EventArgs e)
        {

            //set the form state to Edit
            state = FormStates.Edit;

            EnableEntries(true);//call the EnableEntities method
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {

            if (txtId.Text == "")
            {
                MessageBox.Show("The ID of the Customer is not selected \n Please insert the customer ID first!", "Error", MessageBoxButtons.OK);
            }
            else
            {
                con.Open();
                sqlCommand = new SqlCommand("select ID, Name, Phone, Email, Faxno, Address, PaymentMethod FROM Product where ID ='" + txtId.Text + "'", con);
                SqlDataReader reader = sqlCommand.ExecuteReader();

                while (reader.Read())
                {
                    txtName.Text = reader.GetValue(1).ToString();
                    txtAddress.Text = reader.GetValue(5).ToString();
                    comboBox1.Text = reader.GetValue(6).ToString();
                    txtEmail.Text = reader.GetValue(3).ToString();
                    txtFaxNo.Text = reader.GetValue(4).ToString();
                    txtPhone.Text = reader.GetValue(2).ToString();
                }
                con.Close();

                //PopulateObject();
                //if (state == FormStates.Edit)
                //{
                //    customerController.DataMaintenance(customer , DB.DBOperation.Edit);

                //}
                ////else//delete code
                ////{
                ////    customerController.DataMaintenance(customer, DB.DBOperation.Delete);

                ////}
                //customerController.FinalizeChanges(customer);
                //ClearAll();
                //state = FormStates.View;
                //ShowAll(false);
                //setUpCustomerListView();   //refresh List View
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {

        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            MDIParent1 mdi = new MDIParent1();
            mdi.Show();
            this.Close();
            btnSubmit.Visible = true;
            btnCancel.Visible = true;
        }

        private void tableLayoutPanel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnOkay_Click(object sender, EventArgs e)
        {

        }

        private void lblAddress_Click(object sender, EventArgs e)
        {

        }

        private void CustomerListingForm_Activated_1(object sender, EventArgs e)
        {
            setUpCustomerListView();

        }

        private void btnOkay_Click_1(object sender, EventArgs e)
        {

        }
    }

    
}

