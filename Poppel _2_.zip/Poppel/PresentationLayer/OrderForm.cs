﻿using Poppel.BusinessLayer;
using Poppel.PresentationLayer;
using Poppel.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Poppel
{
    public partial class OrderForm : Form
    {
        private Shopping_Cart cart = new Shopping_Cart();
        private List<OrderListingForm> orders = new List<OrderListingForm>();
        private List<Product>products = new List<Product>();
        private OrderForm orderform;
        public OrderForm()
        {
            InitializeComponent();
            
        }
        
        public OrderForm(ListBox.ObjectCollection objectCollection)
        {
            InitializeComponent();
            this.listBox1.DataSource = objectCollection;
            
           
        }

        public OrderForm(string text)
        {
            Text = text;
        }

        private void drinksToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OrderListingForm drinks = new OrderListingForm();
            drinks.Show();
            this.Hide();
        }

        private void btnCheckout_Click(object sender, EventArgs e)
        {
            Checkout checkout = new Checkout();
            checkout.Show();
            this.Hide();
        }

        private void backToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OrderListingForm drink = new OrderListingForm();
            drink.Show();
        }

        private void listView2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void bindingNavigator1_RefreshItems(object sender, EventArgs e)
        {

        }

        private void comboBoxProduct_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (comboBoxProduct.SelectedIndex == 0) //if drinks is selected
            {
                 listDrinks.Items.Clear();
                listDrinks.Items.AddRange(new object[] { "Iron Brew-2L", "SparLetta Cream Soda-6x2L", "Watermelon Juice-330ml", "Water O-500ml", "Lotus Water-150ml", "Apple Juice-500ml" });
                 
            }
            else if (comboBoxProduct.SelectedIndex == 1) //if confectionary is selected
            {
                listConfectionary.Items.Clear();
                listConfectionary.Items.AddRange(new object[] { "Jelly Beans-350g", "Cand Corn-350g", "Snickers-400g" });
                
            }
        }

        private void bindingNavigatorMoveFirstItem_Click(object sender, EventArgs e)
        {

        }


        private void bindingNavigatorMoveNextItem_Click(object sender, EventArgs e)
        {
            Checkout checkout = new Checkout();
            this.Hide();
            checkout.Show();
        }

        private void OrderForm_Load(object sender, EventArgs e)
        {

        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
        //    if(listBox1.SelectedIndex.Count > 0)
        //    {
        //        string str = Convert.ToString(listBox1.Items[listBox1.SelectedIndices[0]].SubItems[4].Text);
        //        orderform = new OrderForm(str);
        //        orderform.txtPrice.Text = str;
                
        //    }
        }

        private void productsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ProductForm pdf = new ProductForm();
            this.Hide();
            pdf.Show();
        }

        private void catalogueToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Show();
        }

        private void checkoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Checkout checkout = new Checkout();
            this.Hide();
           checkout.Show();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (listConfectionary.SelectedItem != null)
            {
                while (listConfectionary.SelectedItems.Count > 0)
                {
                    listConfectionary.Items.Add(listBox1.SelectedItem);
                    if (listBox1.SelectedItem != null)
                    {
                        while (listBox1.SelectedItems.Count > 0)
                        {
                            listBox1.Items.Add(listBox1.SelectedItem);
                          
                        }
                    }
                    else
                    {
                        MessageBox.Show("No item selected");
                    }
                    listBox1.Items.Remove(listBox1.SelectedItem);
                }
            }
            else
            {
                MessageBox.Show("No item selected");
            }
            string text = listBox1.GetItemText(listDrinks.SelectedItem.ToString());
        }
    }
}
