﻿using Poppel.BusinessLayer;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WMPLib;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using ListView = System.Windows.Forms.ListView;

namespace Poppel.PresentationLayer
{
    public partial class ProductForm : Form

    {
        Url path = new Url("https://www.youtube.com/v/714w3HQDTcA");
        string[] products = { "Coca Cola-2L", "Fanta-330ml", "RedBull-250ml", "Sprite-300ml", "Coca Cola-2l", "Pespi-1.5L", "RedBull-250ml", "Monster-800ml" };

        public object webBrowser1 { get; private set; }
       
        public Collection<string> proD = new Collection<string>();
        public ProductForm(string message)
        {
            InitializeComponent();
            txtHello.Text ="Hello, "+ message;
          
        }
        //instance od order form
      

        public ProductForm()
        {
            InitializeComponent();
            this.Load += new System.EventHandler(this.ProductForm_Load);
        }

        private void bindingNavigatorMoveNextItem_Click(object sender, EventArgs e)
        {
            OrderForm ordform = new OrderForm();
            this.Hide();
            ordform.Show();
        }

        private void bindingNavigatorAddNewItem_Click(object sender, EventArgs e)
        {

        }

        private void bindingNavigatorDeleteItem_Click(object sender, EventArgs e)
        { 
        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 0) //if drinks is selected
            {
                listBoxProducts.Items.Clear();
                listBoxProducts.Items.AddRange(new object[] { "Iron Brew-2L", "SparLetta Cream Soda-6x2L", "Watermelon Juice-330ml", "Water O-500ml", "Lotus Water-150ml", "Apple Juice-500ml" });
                listBoxProducts.SelectedItem = listView;
            }
            else if (comboBox1.SelectedIndex == 1) //if confectionary is selected
            {
                listBoxProducts.Items.Clear();
                listBoxProducts.Items.AddRange(new object[] { "Jelly Beans-350g", "Cand Corn-350g", "Snickers-400g" });
                listBoxProducts.SelectedItem = listView;
            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox2.SelectedIndex == 0)//if Drinks is selected
            {
                listBoxProducts.Items.Clear();
                listBoxProducts.Items.AddRange(new object[] { "Coo-ee-6x2L", "Sprite-1.5L", "RedBull-24x250ml", "Coca Cola-18x300ml", "Jive - 2L", "Pespi Cola-6x330ml", "Score Energy Drink- 6x500ml" });
                listBoxProducts.SelectedItem = listView;
            }
            else if (comboBox2.SelectedIndex ==1)//if confectionary is selected
            {
                listBoxProducts.Items.Clear();
                listBoxProducts.Items.AddRange(new object[] { "Ferrero Rocher-600g", "Kinder joy-75g", "M&M's -75g", "Lays -35g", "Skittles -45g" });
                listBoxProducts.SelectedItem = listView;
            }
        }

        private void ProductForm_Load(object sender, EventArgs e)
        {
            btnAdd.Enabled = true;
            btnAdd.Visible = true;
        

        }

        private void bindingNavigatorMoveLastItem_Click(object sender, EventArgs e)
        {
            Checkout checkout = new Checkout();
            this.Hide();
            checkout.Show();
        }

        private void btnCoca_Click(object sender, EventArgs e)
        {
            listView.Items.Add(products[0]);
        }
        //public string insertlines(string s, int i)
        //{
        //    StringBuilder sb = new StringBuilder();
        //    sb.Append(s);  // create the string
        //    for (int c = 0; c < i; c++)
        //    {
        //        sb.AppendLine(""); // add a line each time
        //    }
        //    return sb.ToString();
        //}

        private void button2_ControlAdded(object sender, ControlEventArgs e)
        {
            CustomerForm test = new CustomerForm();
            test.Show();
        }

        private void tableLayoutPanel2_ControlAdded(object sender, ControlEventArgs e)
        {

        }

        private void btnFanta_Click(object sender, EventArgs e)
        {
            listView.Items.Add(products[1]);

        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void btnRedBull_Click(object sender, EventArgs e)
        {
            listView.Items.Add(products[2]);
        }

        private void btnSprite_Click(object sender, EventArgs e)
        {
            listView.Items.Add(products[3]);
        }

        private void btnCoca_Cola_Click(object sender, EventArgs e)
        {
            listView.Items.Add(products[4]);
        }

        private void btnPespi_Click(object sender, EventArgs e)
        {
            listView.Items.Add(products[5]);
        }

        private void btnredbull1_Click(object sender, EventArgs e)
        {
            listView.Items.Add(products[6]);
        }

        private void btnMonster_Click(object sender, EventArgs e)
        {
            listView.Items.Add(products[7]);
        }

        private void axWindowsMediaPlayer1_Enter(object sender, EventArgs e)
        {
           
        }

        private void listBoxProducts_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            string result = "";
            foreach (string products in listBoxProducts.SelectedItems)
            { result += products + " "; }
            listView.Text = result;
          
        }

        private void button10_Click(object sender, EventArgs e)
        {

        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {
            string Hello = "Hello! " + txtHello.Text;
           
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string text = listBoxProducts.GetItemText(listBoxProducts.SelectedItem);
            listView.Items.Add(text);
            
        }

        private string GetPath()
        {
            return path.ToString();
        }

        private void btnPlay_Click(object sender, EventArgs e, string path)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            if(ofd.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                this.media.URL = path;
                media.Ctlcontrols.play();
            }
            
        }

        private void bindingNavigatorCountItem_Click(object sender, EventArgs e)
        {
         
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            OrderListingForm orderListingForm = new OrderListingForm();
            orderListingForm.Show();
            this.Hide();

        }

        private void listView_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button10_Click_1(object sender, EventArgs e)
        {
            ProductListingForm productListing = new ProductListingForm();
            this.Hide();
            productListing.ShowDialog();  
        }

        private void btnPlay_Click(object sender, EventArgs e)
        {
        
        }
    }
       


}
