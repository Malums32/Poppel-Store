﻿using Poppel.BusinessLayer;
using Poppel.PresentationLayer.CustomerInfo;
using Poppel.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Poppel.PresentationLayer
{
    public partial class MDIParent1 : Form
    {
        #region Varibales
        private int childFormNumber = 0;
        private CustomerForm customerForm;
        private CustomerListingForm customerListingForm;
        private CustomerController customerController;
        #endregion

        #region Constructor
        public MDIParent1()
        {
            InitializeComponent();
            this.WindowState = FormWindowState.Maximized;
            customerController = new CustomerController();
        }
        #endregion

        #region Child forms
        private void ShowNewForm(object sender, EventArgs e)
        {
            Form childForm = new Form();
            childForm.MdiParent = this;
            childForm.Text = "Window " + childFormNumber++;
            childForm.Show();
        }
        #endregion

        #region ToolstripMenus
        private void OpenFile(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
            openFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            if (openFileDialog.ShowDialog(this) == DialogResult.OK)
            {
                string FileName = openFileDialog.FileName;
            }
        }

        private void SaveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
            saveFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            if (saveFileDialog.ShowDialog(this) == DialogResult.OK)
            {
                string FileName = saveFileDialog.FileName;
            }
        }

        private void ExitToolsStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void CutToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void CopyToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void PasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void ToolBarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            toolStrip.Visible = toolBarToolStripMenuItem.Checked;
        }

        private void StatusBarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            statusStrip.Visible = statusBarToolStripMenuItem.Checked;
        }

        private void CascadeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.Cascade);
        }

        private void TileVerticalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.TileVertical);
        }

        private void TileHorizontalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.TileHorizontal);
        }

        private void ArrangeIconsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.ArrangeIcons);
        }

        private void CloseAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (Form childForm in MdiChildren)
            {
                childForm.Close();
            }
        }

        private void toolStrip_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }
        #endregion

        private void productListToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void loginToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            
            Login login = new Login();
            this.Hide();
            login.Show();
        }

        private void registerNewCustomerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            Registration register = new Registration();
            this.Hide();
            register.Show();
        }

        private void addNewCustomerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CustomerForm customerForm = new CustomerForm();
            this.Hide();
            customerForm.Show();
        }

        private void listCustomersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CustomerListingForm custList = new CustomerListingForm();
            this.Hide();
            custList.Show();
        }

        private void listProductsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ProductListingForm prodList = new ProductListingForm();
            this.Hide();
            prodList.Show();
        }

        private void listOrderToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OrderListingForm order = new OrderListingForm();
            this.Hide();
            order.Show();

        }

        private void MDIParent1_Load(object sender, EventArgs e)
        {

        }

        private void listToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void customersToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void loginToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LoginCurrent_Customer current_Customer = new LoginCurrent_Customer();
            current_Customer.Show();
            this.Close();

            //SqlConnection sqlcon = new SqlConnection(Settings.Default.PoppelDBConnectionString);
            //string query = "Select * from tbl_Login Where  Name = '" + txtName.Text.Trim() + "' and Password = '" + txtPassword.Text.Trim() + "'";
            //SqlDataAdapter sda = new SqlDataAdapter(query, sqlcon);
            //DataTable dtbl = new DataTable();
            //sda.Fill(dtbl);
            //if (dtbl.Rows.Count == 1)
            //{
            //    MDIParent1 mdi = new MDIParent1();
            //    mdi.Show();
            //    this.Hide();

            //}
            //else
            //{
            //    MessageBox.Show("Check your name and password");
            //}
        }

        private void contentToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void expiredProductsToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {

        }

        private void helpMenu_Click(object sender, EventArgs e)
        {

        }
    }
    
}
