﻿using Poppel.BusinessLayer;
using System;
using System.Data.SqlClient;
using System.Windows.Forms;
using Poppel.PresentationLayer.CustomerInfo;
using Poppel.PresentationLayer;
using System.Security.Cryptography.X509Certificates;
using Poppel.DatabaseLayer;
using System.Data;
using Poppel.Properties;
using System.Xml.Linq;
using System.Linq.Expressions;

namespace Poppel
{
    public partial class CustomerForm : Form
    {

        #region Data Members
        private Customers customer;
        CustomerController customerController = new CustomerController();
        SqlConnection con;
        public bool customerFormClosed = false;
        #endregion


        public CustomerForm(CustomerController aController)
        {
            InitializeComponent();
            customerController = aController;
            con = new SqlConnection(Settings.Default.PoppelDBConnectionString);
        }

        public CustomerForm()
        {
            InitializeComponent();
            this.Load += new System.EventHandler(this.Sign_Up_Load);
        }

        #region Utility Methods
        private void ShowAll(bool value)
        {   //labels visibility
            lblID.Visible = value;
            lblName.Visible = value;
            lblPhone.Visible = value;
            lblEmail.Visible = value;
            lblFaxNo.Visible = value;
            lblAddress.Visible = value;
            lblPayment.Visible = value;

            //comboboxes visibility
            comboPayment.Visible = value;

            //textboxes visibility
            txtID.Visible = value;
            txtName1.Visible = value;
            txtPhone.Visible = value;
            txtEmail.Visible = value;
            txtFaxNo1.Visible = value;
            txtAddress.Visible = value;


        }
        private void ClearAll()
        {
            txtID.Text = "";
            txtName1.Text = "";
            txtPhone.Text = "";
            txtEmail.Text = "";
            txtFaxNo1.Text = "";
            txtAddress.Text = "";
            //clearing out comboboxes
            comboPayment.Text = "";

        }
        private void PopulateObject()
        {
            Customers custC;
            customer = new Customers();
            string id = txtID.Text;
            string name = txtName1.Text;
            string phone = txtPhone.Text;
            string email = txtEmail.Text;
            string faxNo = txtFaxNo1.Text;
            string address = txtAddress.Text;
            string paymentMethod = comboPayment.Text;
        }


        #endregion



        private void btnSignUp_Click(object sender, EventArgs e)
        {

        }

        private void Sign_Up_Load(object sender, EventArgs e)
        {
            ShowAll(true);
        }
        private void Sign_Up_Activated(object sender, EventArgs e)
        {
            ShowAll(true);
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {

        }

        private void btnRegister_Click_1(object sender, EventArgs e)
        {
            SqlConnection sqlcon = new SqlConnection(Settings.Default.PoppelDBConnectionString);
            string sqlquery = "insert into [dbo].[CustomerDetails] values (@Name,@Phone,@Email,@Faxno,@Address,@PaymentMethod)";
            //sqlcon.Open();
            SqlCommand sqlcom = new SqlCommand(sqlquery, sqlcon);
            sqlcom.Parameters.AddWithValue("@Name", txtName1.Text);
            sqlcom.Parameters.AddWithValue("@Phone", txtPhone.Text);
            sqlcom.Parameters.AddWithValue("@Email", txtEmail.Text);
            sqlcom.Parameters.AddWithValue("@Faxno", txtFaxNo1.Text);
            sqlcom.Parameters.AddWithValue("@Address", txtAddress.Text);
            sqlcom.Parameters.AddWithValue("@PaymentMethod", comboPayment.Text);
            SqlDataReader myReader;
            try
            {
                sqlcon.Open();
                myReader = sqlcom.ExecuteReader();
                MessageBox.Show("\"User \" + txtName1.Text + \" Is Successfully Registered\"");
                while (myReader.Read())
                {

                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
           sqlcon.Close();
        
    //}
    //        sqlcom.ExecuteNonQuery();
    //        string labMsag = "User " + txtName1.Text + " Is Successfully Registered";
    //        MessageBox.Show(labMsag, MessageBoxIcon.Information.ToString());
    //        sqlcon.Close();
            //
            //con = new SqlConnection(Settings.Default.PoppelDBConnectionString);
            //con.Open();
            //SqlCommand sqlCommand = new SqlCommand("insert into CustomerDetails values (@ID, @Name, @Phone, @Email, @Faxno, @Address)", con);
            //sqlCommand.Parameters.AddWithValue("@ID", txtID.Text);
            //sqlCommand.Parameters.AddWithValue("@Name", txtName1.Text);
            //sqlCommand.Parameters.AddWithValue("@Phone", txtPhone.Text);
            //sqlCommand.Parameters.AddWithValue("@Email", txtEmail.Text);
            //sqlCommand.Parameters.AddWithValue("@Faxno", txtFaxNo1.Text);
            //sqlCommand.Parameters.AddWithValue("@Address", txtAddress.Text);
            //sqlCommand.ExecuteNonQuery();
            //con.Close();
            //MessageBox.Show(txtName1.Text + " has been successfully registered into the database.", "Entry Successful", MessageBoxButtons.OK);

            ProductForm productform = new ProductForm();
            this.Hide();
            productform.Show();
        }
        protected string Getstring(string aController, DataRow dataRow)
        {
            if (string.IsNullOrEmpty(Convert.ToString(dataRow[aController])))
                return String.Empty;
            else
            {
                return Convert.ToString(dataRow[aController]);
            }
        }

            private void btnShow_Click(object sender, EventArgs e)
        {
            CustomerListingForm cuslfrm = new CustomerListingForm();
            this.Hide();
            cuslfrm.ShowDialog();
        }

        private void listViewSignUp_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            MDIParent1 mdi = new MDIParent1();
            mdi.Show();
            this.Hide();
        }
    }
}
