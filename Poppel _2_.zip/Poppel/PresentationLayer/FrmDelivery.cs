﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Poppel.BusinessLayer
{
     class FrmDelivery :Form
    {

        ListBox listView1;
        public string DisplayProduct
        {
            get { return listView1.Text; }
           

        }

        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // FrmDelivery
            // 
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Name = "FrmDelivery";
            this.Load += new System.EventHandler(this.FrmDelivery_Load);
            this.ResumeLayout(false);

        }

        private void FrmDelivery_Load(object sender, EventArgs e)
        {

        }
    }
}
