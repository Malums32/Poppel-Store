﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace Poppel.PresentationLayer.CustomerInfo
{
    
    public partial class Registration : Form
    {
        
        public Registration()
        {
            InitializeComponent();
            linkLabelLogin.Visible =false;
        }

        private void btnReg_Click(object sender, EventArgs e)
        {
            SqlConnection sqlcon = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\mfundo mthembu\source\repos\Poppel\LoginDB.mdf;Integrated Security=True;Connect Timeout=30");
            string sqlquery = "insert into [dbo].[tbl_Login] values (@Name,@Password,@ConfirmPassword,@Email,@Location,@Gender)";
            sqlcon.Open();
            SqlCommand sqlcom = new SqlCommand(sqlquery, sqlcon);
            string gender = radioMale.Checked ? "M" : "F";
            sqlcom.Parameters.AddWithValue("@Name",txtName.Text);
            sqlcom.Parameters.AddWithValue("@Password", txtPassword.Text);
            sqlcom.Parameters.AddWithValue("@ConfirmPassword", txtConfirmPass.Text);
            sqlcom.Parameters.AddWithValue("@Email", txtEmail.Text);
            sqlcom.Parameters.AddWithValue("@Location", comboLocation.Text);
            sqlcom.Parameters.AddWithValue("@Gender", gender);
            sqlcom.ExecuteNonQuery();
            string labMsag = "User " + txtName.Text + " Is Successfully Registered";
            MessageBox.Show(labMsag, MessageBoxIcon.Information.ToString());
            linkLabelLogin.Visible = true;
            sqlcon.Close();
            

        }

        private void Registration_Load(object sender, EventArgs e)
        {
           
        }

        private void linkLabelLogin_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Login log = new Login();
            this.Hide();
            log.Show();
        }

        private void txtConfirmPass_Leave(object sender, EventArgs e)
        {
            if(txtPassword.Text != txtConfirmPass.Text)
            {
                MessageBox.Show("Password Is Not Matching");
                txtConfirmPass.Focus();
                return;
            }
        }

        private void lblPoppel_Click(object sender, EventArgs e)
        {

        }
    }
}
