﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;
using Poppel.Properties;

namespace Poppel.PresentationLayer.CustomerInfo
{
    public partial class Login : Form
    {

      
        private int encryptNumber = 32;
        public Login()
        {
            InitializeComponent();
            
        }
        
        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            SqlConnection sqlcon = new SqlConnection(Settings.Default.LoginDBConnectionString);
            string query = "Select * from tbl_Login Where  Name = '" + txtName.Text.Trim() + "' and Password = '" + txtPassword.Text.Trim() + "'";
            SqlDataAdapter sda = new SqlDataAdapter(query, sqlcon);
            DataTable dtbl = new DataTable();
            sda.Fill(dtbl);
            if (dtbl.Rows.Count == 1)
            {
                MDIParent1 mdi = new MDIParent1();
                mdi.Show();
                this.Hide();

            }
            else
            {
                MessageBox.Show("Check your name and password");
            }
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            Registration reg = new Registration();
            this.Hide();
            reg.Show();
        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
