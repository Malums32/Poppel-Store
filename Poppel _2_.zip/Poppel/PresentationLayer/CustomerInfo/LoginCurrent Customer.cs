﻿using Poppel.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Poppel.PresentationLayer.CustomerInfo
{

    public partial class LoginCurrent_Customer : Form
    {
        SqlConnection conn;
        public LoginCurrent_Customer()
        {
            InitializeComponent();
            conn = new SqlConnection(Settings.Default.PoppelDBConnectionString);
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            MDIParent1 mDIParent1 = new MDIParent1();   
            mDIParent1.Show();
            this.Hide();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
               
            if(txtID.Text == "" || txtName2.Text == "" )
            {
                MessageBox.Show("You are missing variables for the ID or Name", "Error error!", MessageBoxButtons.OK);
                return;
            }
            conn.Open();
            SqlCommand check_User_Name = new SqlCommand("SELECT 2 FROM CustomerDetails WHERE ID=@ID , Name=@Name", conn);
            check_User_Name.Parameters.Add("@Name",SqlDbType.NChar).Value = txtName2.Text;
            check_User_Name.Parameters.Add("@ID", SqlDbType.Int).Value = txtID.Text;

            int UserExist = (int)check_User_Name.ExecuteScalar();

            if (UserExist > 0)
            {
                ProductForm productform = new ProductForm();
                productform.Show();
                this.Close();
            }
            else
            {
                MessageBox.Show("The ID or Name might be wrong \n Please re-enter the values", "Entry Error!", MessageBoxButtons.OK);
            }
            check_User_Name.ExecuteNonQuery();
            //ProductForm productForm = new ProductForm();
            //productForm.Show();
            //this.Hide();
        }
    }
}
