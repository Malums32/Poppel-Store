﻿using Poppel.PresentationLayer;
using Poppel.PresentationLayer.CustomerInfo;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Poppel
{
    public partial class Checkout : Form
    {
        public Checkout()
        {
            InitializeComponent();
        }

        private void btnPrevoius_Click(object sender, EventArgs e)
        {
            OrderForm catalogue = new OrderForm();
            catalogue.Show();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            OrderForm catalogue = new OrderForm();
            catalogue.Show();
        }

        private void btnEdit_Click_1(object sender, EventArgs e)
        {
            OrderForm catalogue = new OrderForm();
            catalogue.Show();
        }

        private void btnFinish_Click(object sender, EventArgs e)
        {
            
           MessageBox.Show("YOU HAVE SUCCESSFULLY MADE YOUR PURCHASE \n HOPE TO SEE YOU SOON ❤️😊🤗🔐 ","Note!", MessageBoxButtons.OK);
          Login log = new Login();
            log.Show();
        }

        private void Checkout_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void btnPersonalDetails_Click(object sender, EventArgs e)
        {

        }

       

        private void rbnPersonalDetails_CheckedChanged(object sender, EventArgs e)
        {
           
        }

        private void rbnConfirmation_CheckedChanged(object sender, EventArgs e)
        {
            
           
        }
    }
}
