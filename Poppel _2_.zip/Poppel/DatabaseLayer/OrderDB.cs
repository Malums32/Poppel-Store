﻿using Poppel.Properties;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Poppel.BusinessLayer;
using System.Collections.ObjectModel;

namespace Poppel.DatabaseLayer
{
     public class OrderDB: DB
     {
        SqlConnection con = new SqlConnection("@Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\mfundo mthembu\\source\\repos\\Poppel\\PoppelDB.mdf;Integrated Security=True;Connect Timeout=30");

        #region  Data members 
        private string table2 = "Order";
        private string sqlLocal2 = "SELECT * FROM Order";

        private Collection<BusinessLayer.Order> orders;
        #endregion


        #region Property Method: Collection
        public Collection<BusinessLayer.Order> AllOrders
        {
            get
            {
                return orders;
            }
        }
        #endregion

        #region Constructor
        public OrderDB() : base()
        {
            orders = new Collection<BusinessLayer.Order>();
            FillDataSet(sqlLocal2, table2);
            Add2Collection(table2);

        }
        #endregion

        #region Utility Methods
        public DataSet GetDataSet()
        {
            return dsMain;
        }
        private void Add2Collection(string table)
        {
            //Declare references to a myRow object and an Customer object
            DataRow myRow = null;
            BusinessLayer.Order aOrd;
            orders.Add(aOrd = new BusinessLayer.Order());

            //READ from the table  
            foreach (DataRow myRow_loopVariable in dsMain.Tables[table].Rows)
            {
                myRow = myRow_loopVariable;
                if (!(myRow.RowState == DataRowState.Deleted))
                {
                    //Instantiate a new Customer object
                    aOrd = new BusinessLayer.Order();
                    //Obtain each order attribute from the specific field in the row in the table
                    aOrd.OrderID = Convert.ToString(myRow["OrderID"]).TrimEnd();
                    //Do the same for all other attributes
                    aOrd.OrderName = Convert.ToString(myRow["OrderName"]).TrimEnd();
                    aOrd.OrderType = Convert.ToString(myRow["OrderType"]).TrimEnd();
                    aOrd.OrderDate = Convert.ToString(myRow["OrderDate"]).TrimEnd();
                    aOrd.OrderPrice = Convert.ToString(myRow["OrderPrice"]);
                    aOrd.OrderQty = Convert.ToString(myRow["OrderQty"]);
                    aOrd.Description = Convert.ToString(myRow["Description"]);  
                }
                orders.Add(aOrd);
            }
        }
        private void FillRow(DataRow aRow, BusinessLayer.Order aOrd, DB.DBOperation operation)
        {
            if (operation == DB.DBOperation.Add)
            {
                aRow["OrderID"] = aOrd. OrderID;  //NOTE square brackets to indicate index of collections of fields in row.
                aRow["OrderName"] = aOrd.OrderName;
            }
            aRow["OrderType"] = aOrd.OrderType;
            aRow["OrderDate"] = aOrd.OrderDate;
            aRow["OrderPrice"] = aOrd.OrderPrice;
            aRow["OrderQty"] = aOrd.OrderQty;
            aRow["Description"] = aOrd.Description;

        }
        private int FindRow(BusinessLayer.Order aOrd, string table)
        {
            int rowIndex = 0;
            DataRow myRow;
            int returnValue = -1;
            foreach (DataRow myRow_loopVariable in dsMain.Tables[table].Rows)
            {
                myRow = myRow_loopVariable;
                //Ignore rows marked as deleted in dataset
                if (!(myRow.RowState == DataRowState.Deleted))
                {
                    //In c# there is no item property (but we use the 2-dim array) it 
                    //is automatically known to the compiler when used as below
                    if (aOrd.OrderID == Convert.ToString(dsMain.Tables[table].Rows[rowIndex]["OrderID"]))
                    {
                        returnValue = rowIndex;
                    }
                }
                rowIndex += 1;
            }
            return returnValue;
        }
        #endregion

        #region Database Operations CRUD
        public void DataSetChange(BusinessLayer.Order aOrd, DB.DBOperation operation)
        {
            DataRow aRow = null;
            string dataTable = table2;

            dataTable = table2;


            switch (operation)
            {
                case DB.DBOperation.Add:
                    aRow = dsMain.Tables[dataTable].NewRow();
                    FillRow(aRow, aOrd, operation);
                    dsMain.Tables[dataTable].Rows.Add(aRow);
                    break;
                case DB.DBOperation.Edit:
                    aRow = dsMain.Tables[dataTable].Rows[FindRow(aOrd, dataTable)];
                    FillRow(aRow, aOrd, operation);
                    break;
                //case DB.DBOperation.Delete:
                //    aRow = dsMain.Tables[dataTable].Rows[FindRow(aOrd, dataTable)];
                //    dsMain.Tables[dataTable].Rows.Remove(aRow);


                //    break;
            }
        }
        #endregion

        #region Build Parameters, Create Commands & Update database
        private void Build_INSERT_Parameters(BusinessLayer.Order aOrd)
        {
            //Create Parameters to communicate with SQL INSERT...
            //add the input parameter and set its properties.             
            SqlParameter param = default(SqlParameter);
            param = new SqlParameter("@OrderID", SqlDbType.NChar, 50, "OrderID");
            daMain.InsertCommand.Parameters.Add(param);//Add the parameter to the Parameters collection.

            param = new SqlParameter("@OrderName", SqlDbType.NChar, 50, "OrderName");
            daMain.InsertCommand.Parameters.Add(param);

            param = new SqlParameter("@OrderType", SqlDbType.NChar, 50, "OrderType");
            daMain.InsertCommand.Parameters.Add(param);

            param = new SqlParameter("@OrderDate", SqlDbType.NChar, 50, "OrderDate");
            daMain.InsertCommand.Parameters.Add(param);

            param = new SqlParameter("@OrderPrice", SqlDbType.NChar, 50, "OrderPrice");
            daMain.InsertCommand.Parameters.Add(param);

            param = new SqlParameter("@OrderQty", SqlDbType.NChar, 50, "OrderQty");
            daMain.InsertCommand.Parameters.Add(param);

            param = new SqlParameter("@Description", SqlDbType.NChar, 50, "Description");
            daMain.InsertCommand.Parameters.Add(param);

        }
        private void Build_UPDATE_Parameters(BusinessLayer.Order aOrd)
        {
            //---Create Parameters to communicate with SQL UPDATE
            SqlParameter param = default(SqlParameter);

            param = new SqlParameter("@OrderName", SqlDbType.NChar, 50, "OrderName");
            param.SourceVersion = DataRowVersion.Current;
            daMain.UpdateCommand.Parameters.Add(param);

            //Do for all fields other than ID 
            param = new SqlParameter("@OrderType", SqlDbType.NChar, 50, "OrderType");
            param.SourceVersion = DataRowVersion.Current;
            daMain.UpdateCommand.Parameters.Add(param);

            param = new SqlParameter("@OrderDate", SqlDbType.NChar, 50, "OrderDate");
            param.SourceVersion = DataRowVersion.Current;
            daMain.UpdateCommand.Parameters.Add(param);

            param = new SqlParameter("@OrderPrice", SqlDbType.NChar, 50, "OrderPrice");
            param.SourceVersion = DataRowVersion.Current;
            daMain.UpdateCommand.Parameters.Add(param);

            param = new SqlParameter("@OrderQty", SqlDbType.NChar, 50, "OrderQty");
            param.SourceVersion = DataRowVersion.Current;
            daMain.UpdateCommand.Parameters.Add(param);

            //testing the ID of record that needs to change with the original ID of the record
            param = new SqlParameter("@OrderID", SqlDbType.NChar, 50, "OrderID");
            param.SourceVersion = DataRowVersion.Original;
            daMain.UpdateCommand.Parameters.Add(param);
        }
        private void Create_INSERT_Command(BusinessLayer.Order aOrd)
        {
            //Create the command that must be used to insert values into the table..
            daMain.InsertCommand = new SqlCommand("INSERT into Order (OrderID, OrderName, OrderType, OrderDate, OrderPrice, OrderQty) VALUES (@OrderID, @OrderName, @OrderType, @OrderDate, @OrderPrice, @OrdeerQty)", cnMain);

            Build_INSERT_Parameters(aOrd);
        }
        
        private void Create_UPDATE_Command(BusinessLayer.Order aOrd)
        {
            //Create the command that must be used to insert values into one of the three tables
            //Assumption is that the ID is correct

            daMain.UpdateCommand = new SqlCommand("UPDATE Order SET Name =@OrderName, Type =@OrderType, Date =@OrderDate, Price =@OrderPrice, Qty =@OrderQty " + "WHERE ID = @Original_ID", cnMain);

            Build_UPDATE_Parameters(aOrd);
        }
        public bool UpdateDataSource(BusinessLayer.Order aOrd)
        {
            bool success = true;
            Create_INSERT_Command(aOrd);
            Create_UPDATE_Command(aOrd);
            success = UpdateDataSource(sqlLocal2, table2);

            return success;
        }

        #endregion

    }
}
