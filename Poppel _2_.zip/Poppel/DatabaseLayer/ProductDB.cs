﻿using Poppel.BusinessLayer;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Poppel.DatabaseLayer
{
    public class ProductDB : DB
    {

        #region  Data members 
        private string table3 = "Product";
        private string sqlLocal3 = "SELECT * FROM Product";

        private Collection<Product> products;
        #endregion

        #region Property Method: Collection
        public Collection<Product> AllProducts
        {
            get
            {
                return products;
            }
        }
        #endregion

        #region Constructor
        public ProductDB() : base()
        {
            products = new Collection<Product>();
            FillDataSet(sqlLocal3, table3);
            Add2Collection(table3);

        }
        #endregion

        #region Utility Methods
        public DataSet GetDataSet()
        {
            return dsMain;
        }
        private void Add2Collection(string table)
        {
            //Declare references to a myRow object and an Customer object
            DataRow myRow = null;
            Product aPro;
            products.Add(aPro = new Product());

            //READ from the table  
            foreach (DataRow myRow_loopVariable in dsMain.Tables[table].Rows)
            {
                myRow = myRow_loopVariable;
                if (!(myRow.RowState == DataRowState.Deleted))
                {
                    //Instantiate a new Product object
                    aPro = new Product();
                    //Obtain each Product attribute from the specific field in the row in the table
                    aPro.ProductCode = Convert.ToString(myRow["ProductCode"]).TrimEnd();
                    //Do the same for all other attributes
                    aPro.ProductName = Convert.ToString(myRow["ProductName"]).TrimEnd();
                    aPro.ProductSize = Convert.ToString(myRow["ProductSize"]).TrimEnd();
                    aPro.ProductQuantity = Convert.ToString(myRow["ProductQuantity"]);
                    aPro.ProductPrice = Convert.ToString(myRow["ProductPrice"]).TrimEnd();
                    aPro.Description = Convert.ToString(myRow["Description"]);
                }
                products.Add(aPro);
            }
        }
        private void FillRow(DataRow aRow, Product aPro, DB.DBOperation operation)
        {
            if (operation == DB.DBOperation.Add)
            {
                aRow["ProductCode"] = aPro.ProductCode;  //NOTE square brackets to indicate index of collections of fields in row.
                aRow["ProductName"] = aPro.ProductName;
            }
            aRow["ProductSize"] = aPro.ProductSize;
            aRow["ProductQuantity"] = aPro.ProductQuantity;
            aRow["ProductPrice"] = aPro.ProductPrice;
            aRow["Description"] = aPro.Description;

        }
        private int FindRow(Product aPro, string table)
        {
            int rowIndex = 0;
            DataRow myRow;
            int returnValue = -1;
            foreach (DataRow myRow_loopVariable in dsMain.Tables[table].Rows)
            {
                myRow = myRow_loopVariable;
                //Ignore rows marked as deleted in dataset
                if (!(myRow.RowState == DataRowState.Deleted))
                {
                    //In c# there is no item property (but we use the 2-dim array) it 
                    //is automatically known to the compiler when used as below
                    if (aPro.ProductCode == Convert.ToString(dsMain.Tables[table].Rows[rowIndex]["ProductCode"]))
                    {
                        returnValue = rowIndex;
                    }
                }
                rowIndex += 1;
            }
            return returnValue;
        }
        #endregion

        #region Database Operations CRUD
        public void DataSetChange(Product aPro, DB.DBOperation operation)
        {
            DataRow aRow = null;
            string dataTable = table3;

            dataTable = table3;


            switch (operation)
            {
                case DB.DBOperation.Add:
                    aRow = dsMain.Tables[dataTable].NewRow();
                    FillRow(aRow, aPro, operation);
                    dsMain.Tables[dataTable].Rows.Add(aRow);
                    break;
                case DB.DBOperation.Edit:
                    aRow = dsMain.Tables[dataTable].Rows[FindRow(aPro, dataTable)];
                    FillRow(aRow, aPro, operation);
                    break;
                //case DB.DBOperation.Delete:
                //    aRow = dsMain.Tables[dataTable].Rows[FindRow(aPro, dataTable)];
                //    dsMain.Tables[dataTable].Rows.Remove(aRow);


                    //break;
            }
        }
        #endregion

        #region Build Parameters, Create Commands & Update database
        private void Build_INSERT_Parameters(Product aPro)
        {
            //Create Parameters to communicate with SQL INSERT...
            //add the input parameter and set its properties.             
            SqlParameter param = default(SqlParameter);
            param = new SqlParameter("@productCode", SqlDbType.NChar, 50, "productCode");
            daMain.InsertCommand.Parameters.Add(param);//Add the parameter to the Parameters collection.

            param = new SqlParameter("@productName", SqlDbType.NChar, 50, "productName");
            daMain.InsertCommand.Parameters.Add(param);

            param = new SqlParameter("@productSize", SqlDbType.NChar, 50, "productSize");
            daMain.InsertCommand.Parameters.Add(param);

            param = new SqlParameter("@productQuantity", SqlDbType.NChar, 50, "productQuantity");
            daMain.InsertCommand.Parameters.Add(param);

            param = new SqlParameter("@productPrice", SqlDbType.NChar, 50, "productPrice");
            daMain.InsertCommand.Parameters.Add(param);

            param = new SqlParameter("@Description", SqlDbType.NChar, 50, "Description");
            daMain.InsertCommand.Parameters.Add(param);

        }
        private void Build_UPDATE_Parameters(Product aPro)
        {
            //---Create Parameters to communicate with SQL UPDATE
            SqlParameter param = default(SqlParameter);

            param = new SqlParameter("@productName", SqlDbType.NChar, 50, "productName");
            param.SourceVersion = DataRowVersion.Current;
            daMain.UpdateCommand.Parameters.Add(param);

            //Do for all fields other than ID 
            param = new SqlParameter("@productSize", SqlDbType.NChar, 50, "productSize");
            param.SourceVersion = DataRowVersion.Current;
            daMain.UpdateCommand.Parameters.Add(param);

            param = new SqlParameter("@productQuantity", SqlDbType.NChar, 50, "productQuantity");
            param.SourceVersion = DataRowVersion.Current;
            daMain.UpdateCommand.Parameters.Add(param);

            param = new SqlParameter("@productPrice", SqlDbType.NChar, 50, "productPrice");
            param.SourceVersion = DataRowVersion.Current;
            daMain.UpdateCommand.Parameters.Add(param);

            param = new SqlParameter("@Description", SqlDbType.NChar, 50, "Description");
            param.SourceVersion = DataRowVersion.Current;
            daMain.UpdateCommand.Parameters.Add(param);

            //testing the ID of record that needs to change with the original ID of the record
            param = new SqlParameter("@productCode", SqlDbType.NChar, 50, "productCode");
            param.SourceVersion = DataRowVersion.Original;
            daMain.UpdateCommand.Parameters.Add(param);
        }
        private void Create_INSERT_Command(Product aPro)
        {
            //Create the command that must be used to insert values into the table..
            daMain.InsertCommand = new SqlCommand("INSERT into Product (productCode, productName, productSize, productQuantity, productPrice, description) VALUES (@productCode, @productName, @productSize, @productQuantity, @productPrice, @description)", cnMain);

            Build_INSERT_Parameters(aPro);
        }
        private void Create_UPDATE_Command(Product aPro)
        {
            //Create the command that must be used to insert values into one of the three tables
            //Assumption is that the ID is correct

            daMain.UpdateCommand = new SqlCommand("UPDATE Product SET productName =@productName, productSize =@productSize, productQuantity =@productQuantity, productPrice =@productPrice, description =@description " + "WHERE productCode = @productCode", cnMain);

            Build_UPDATE_Parameters(aPro);
        }
        public bool UpdateDataSource(Product aPro)
        {
            bool success = true;
            Create_INSERT_Command(aPro);
            Create_UPDATE_Command(aPro);
            success = UpdateDataSource(sqlLocal3, table3);

            return success;
        }

        #endregion
    }
}
