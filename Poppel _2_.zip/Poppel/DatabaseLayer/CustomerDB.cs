﻿using Poppel.BusinessLayer;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Poppel.DatabaseLayer
{
    public class CustomerDB : DB
    {

        #region  Data members 
        private string table1 = "CustomerDetails";
        private string sqlLocal1 = "SELECT * FROM CustomerDetails";

        private Collection<Customers> customer;
        #endregion

        #region Property Method: Collection
        public Collection<Customers> AllCustomers
        {
            get
            {
                return customer;
            }
        }
        #endregion

        #region Constructor
        public CustomerDB() : base()
        {
            customer = new Collection<Customers>();
            FillDataSet(sqlLocal1, table1);
            Add2Collection(table1);

        }
        #endregion

        #region Utility Methods
        public DataSet GetDataSet()
        {
            return dsMain;
        }
        private void Add2Collection(string table)
        {
            //Declare references to a myRow object and an Customer object
            DataRow myRow = null;
            Customers anCus;
            customer.Add(anCus = new Customers());

            //READ from the table  
            foreach (DataRow myRow_loopVariable in dsMain.Tables[table].Rows)
            {
                myRow = myRow_loopVariable;
                if (!(myRow.RowState == DataRowState.Deleted))
                {
                    //Instantiate a new Customer object
                    anCus = new Customers();
                    //Obtain each customer attribute from the specific field in the row in the table
                    anCus.ID = Convert.ToInt32(myRow["ID"]).ToString();
                    //Do the same for all other attributes
                    anCus.Name = Convert.ToString(myRow["Name"]).TrimEnd();
                    anCus.Phone = Convert.ToString(myRow["Phone"]).TrimEnd();
                    anCus.Email = Convert.ToString(myRow["Email"]).TrimEnd();
                    anCus.Faxno = Convert.ToString(myRow["Faxno"]).TrimEnd();
                    anCus.Address = Convert.ToString(myRow["Address"]).TrimEnd();
                    anCus.PaymentMethod = Convert.ToString(myRow["PaymentMethod"]).TrimEnd();
                }
               customer.Add(anCus);
            }
        }
        private void FillRow(DataRow aRow, Customers anCus, DB.DBOperation operation)
        {
            Customers customers;
            if (operation == DB.DBOperation.Add)
            {
                //aRow["ID"] = Convert.ToInt32(anCus.ID); //NOTE square brackets to indicate index of collections of fields in row.
                aRow["Name"] = anCus.Name;
            }
            aRow["Phone"] = anCus.Phone;
            aRow["Email"] = anCus.Email;
            aRow["Faxno"] = anCus.Faxno;
            aRow["Address"] = anCus.Address;
            aRow["PaymentMethod"] = anCus.PaymentMethod;

        }
        private int FindRow(Customers anCus, string table)
        {
            int rowIndex = 0;
            DataRow myRow;
            int returnValue = -1;
            foreach (DataRow myRow_loopVariable in dsMain.Tables[table].Rows)
            {
                myRow = myRow_loopVariable;
                //Ignore rows marked as deleted in dataset
                
                    if (anCus.ID == Convert.ToString(dsMain.Tables[table].Rows[rowIndex]["ID"]))
                    {
                        returnValue = rowIndex;
                    }
                
                rowIndex += 1;
            }
            return returnValue;
        }
        #endregion

        #region Database Operations CRUD
        public void DataSetChange(Customers anCus, DB.DBOperation operation)
        {
            DataRow aRow = null;
            string dataTable = table1;

                    switch (operation)
                    {
                case DB.DBOperation.Add:
                    aRow = dsMain.Tables[dataTable].NewRow();
                    FillRow(aRow, anCus , operation);
                    dsMain.Tables[dataTable].Rows.Add(aRow);
                    break;
                case DB.DBOperation.Edit:
                    aRow = dsMain.Tables[dataTable].Rows[FindRow(anCus, dataTable)];
                    FillRow(aRow, anCus, operation);
                    break;
                
                    }
        }
        #endregion

        #region Build Parameters, Create Commands & Update database
        private void Build_INSERT_Parameters(Customers anCus)
        {
            //Create Parameters to communicate with SQL INSERT...
            //add the input parameter and set its properties.             
            SqlParameter param = default(SqlParameter);
            //param = new SqlParameter("@ID", SqlDbType.Int, 000);
            //daMain.InsertCommand.Parameters.Add(param);//Add the parameter to the Parameters collection.

            param = new SqlParameter("@Name", SqlDbType.NChar, 50, "Name");
            daMain.InsertCommand.Parameters.Add(param);

            param = new SqlParameter("@Phone", SqlDbType.NChar, 55, "Phone");
            daMain.InsertCommand.Parameters.Add(param);

            param = new SqlParameter("@Email", SqlDbType.NChar, 50, "Email");
            daMain.InsertCommand.Parameters.Add(param);

            param = new SqlParameter("@FaxNo", SqlDbType.NChar, 50, "FaxNo");
            daMain.InsertCommand.Parameters.Add(param);

            param = new SqlParameter("@Address", SqlDbType.NChar, 50, "Email");
            daMain.InsertCommand.Parameters.Add(param);

            param = new SqlParameter("@PaymentMethod", SqlDbType.NChar, 50, "PaymentMethod");
            daMain.InsertCommand.Parameters.Add(param);

        }
        private void Build_UPDATE_Parameters(Customers anCus)
        {
            //---Create Parameters to communicate with SQL UPDATE
            SqlParameter param = default(SqlParameter);

            param = new SqlParameter("@Name", SqlDbType.NChar, 50, "Name");
            param.SourceVersion = DataRowVersion.Current;
            daMain.UpdateCommand.Parameters.Add(param);

            //Do for all fields other than ID 
            param = new SqlParameter("@Phone", SqlDbType.NChar, 50, "Phone");
            param.SourceVersion = DataRowVersion.Current;
            daMain.UpdateCommand.Parameters.Add(param);

            param = new SqlParameter("@Email", SqlDbType.NChar, 50, "Email");
            param.SourceVersion = DataRowVersion.Current;
            daMain.UpdateCommand.Parameters.Add(param);

            param = new SqlParameter("@FaxNo", SqlDbType.NChar, 50, "FaxNo");
            param.SourceVersion = DataRowVersion.Current;
            daMain.UpdateCommand.Parameters.Add(param);

            param = new SqlParameter("@Address", SqlDbType.NChar, 50, "Address");
            param.SourceVersion = DataRowVersion.Current;
            daMain.UpdateCommand.Parameters.Add(param);

            param = new SqlParameter("@PaymentMethod", SqlDbType.NChar, 50, "PaymentMethod");
            param.SourceVersion = DataRowVersion.Current;
            daMain.UpdateCommand.Parameters.Add(param);

            //testing the ID of record that needs to change with the original ID of the record
            //param = new SqlParameter("@ID", SqlDbType.Int, 000);
            //param.SourceVersion = DataRowVersion.Original;
            daMain.UpdateCommand.Parameters.Add(param);
        }
        private void Create_INSERT_Command(Customers anCus)
        {
            //Create the command that must be used to insert values into the table..
           daMain.InsertCommand = new SqlCommand("INSERT into CustomerDetails (Name, Phone, Email, FaxNo, Address, PaymentMethod) VALUES (@Name, @Phone, @Email, @FaxNo, @Address, @PaymentMethod)", cnMain);
           
            Build_INSERT_Parameters(anCus);
        }
        private void Create_UPDATE_Command(Customers anCus)
        {
            //Create the command that must be used to insert values into the table
            

             daMain.UpdateCommand = new SqlCommand("UPDATE CustomerDetails SET Name =@Name, Phone =@Phone, Email =@Email, FaxNo =@FaxNo, Address =@Address, PaymentMethod =@PaymentMethod " + "WHERE ID = @ID", cnMain);
                   
            Build_UPDATE_Parameters(anCus);
        }
        public bool UpdateDataSource(Customers anCus)
        {
            bool success = true;
            Create_INSERT_Command(anCus);
            Create_UPDATE_Command(anCus);
            success = UpdateDataSource(sqlLocal1, table1);
                   
            return success;
        }

        #endregion

    }
}



